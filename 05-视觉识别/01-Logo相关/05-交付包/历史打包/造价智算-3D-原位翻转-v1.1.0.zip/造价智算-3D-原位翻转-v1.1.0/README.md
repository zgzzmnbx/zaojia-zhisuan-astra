# 造价智算 · 阶梯 Z 原位翻转

版本：1.1.0 · 2026-10-13

沿用用户选定的第 5 号阶梯 Z 概念：上下横梁和三个阶梯方块，共五个可独立编辑的网格。根据用户提供的 Sketchfab 录屏，将中间方块改为原位换轴翻转。仍属独立概念方案。

## 直接查看

- `造价智算-原位翻转-v1.1.mp4`：Blender 实际渲染，720×720、30 fps、6.6 秒，无音轨。
- `造价智算-3D-动效预览.html`：离线交互预览，代码与模型内嵌；使用支持 WebGL2 的 Edge / Chrome 打开。可拖动、缩放、暂停、播放一轮、复位、切换背景及光照。
- `Blender/造价智算-阶梯Z-原位翻转-v1.1.0.blend`：包含五个部件、动画、摄影机、灯光及地面。双击打开，空格播放 / 暂停，F12 渲染当前帧。
- `ZSuan-Stepped-Z-animated-v1.1.glb`：适合其他三维软件或网页使用，包含几何、材质和动画；不包含 Blender 的摄影棚。
- `Blender/造价智算-原位翻转-v1.1.png`：1080×1080 静帧。

本机已有 Blender 5.2.2 LTS，本次不需要另装软件。网页预览自身无需 Blender。

## 动作设计

固定镜头下，中间方块绕自身中心翻转，三个空间轴依次切换。每次翻转 0.6 秒、随后停顿 0.4 秒；一轮六次，含首尾停顿总长 6.6 秒。上下横梁及两侧阶梯保持静止。旋转过程中方块暂时收小，停顿时恢复原比例，避免旋转边角扩大原有阶梯接触处的重叠；最小约为原边长的 71%。

此处借鉴录屏可观察到的“原位、多轴、快转后停顿”节奏；转轴、角度和时长是针对智算标志重新设计的参数，不是对参考原始动画数据的精确恢复。模型由本项目自行生成，未下载或使用 Sketchfab 模型几何。

网页离屏或隐藏时停止渲染；系统减少动效开启时默认静止，可手动开始播放。`.blend` 帧率 30、范围 0–197，动画关键帧以 120 Hz 采样，最后停顿确保循环闭合。

## 来源

- 静态结构：用户指定的 `【5】ChatGPT Image 2026年7月25日 10_20_03.png`，原文件只读。
- 动作参考：用户提供的 `C:\Users\zgzzm\Desktop\bandicam 2026-10-13 10-45-18-638.mp4`。
- 用户给出的参考网页：https://sketchfab.com/3d-models/sketchfab-logo-free-download-e400557705fa4fdb89a63ec9dabb825a 。网页内容未完整加载，动作判断依据本地录屏。
- 开源依赖：Three.js、daisyUI，许可证见 `THIRD-PARTY-LICENSES.txt`。

## 重建与验证

在 Astra 根目录使用现有 Node.js 依赖运行：

```powershell
node Codex-Temp/logo-3d-v1.1/build.mjs
node Codex-Temp/logo-3d-v1.1/verify.mjs
```

`build_blender.py` 从相邻 `logo-3d-v1/Blender/` 工程复制摄影棚，导入新 GLB，保存到当前目录并渲染；不修改旧工程，不保存全局偏好。生成的 `.blend` 可独立使用，不依赖旧版文件。

程序检查见 `verification.json`：重新加载导出的 GLB，检查五个网格、静态部件、原位旋转、停顿、归位、循环、暂停，并以 360 Hz 采样验证旋转包围盒未扩大原有占用范围。它不宣称原概念各部件本来就是无交叠装配体。

Blender 检查见 `blender-verification.json`、`blender-reopen-verification.json`；视频及交付文件检查见 `delivery-verification.json`。视频是 Blender 原生渲染，并非网页录屏。离线 HTML 已通过脚本语法和内嵌资源检查；由于内置浏览器此前拒绝 `file://`，本次没有绕过限制，网页交互及明暗主题实看仍待本机打开验收。

原 v1.0.0 保留在相邻 `logo-3d-v1/`。本次版本记录见本目录 `CHANGELOG.md`。
